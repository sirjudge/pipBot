var classArServerDeleteFileOnServer =
[
    [ "ArServerDeleteFileOnServer", "classArServerDeleteFileOnServer.html#af58277347e3f04e44227ae5fcd6a8618", null ],
    [ "~ArServerDeleteFileOnServer", "classArServerDeleteFileOnServer.html#a8ddc6674d1dd0b4023c3e7bdc9a85815", null ],
    [ "addPostDeleteCallback", "classArServerDeleteFileOnServer.html#a06eb81621a23e2d61afb95787c34c110", null ],
    [ "addPreDeleteCallback", "classArServerDeleteFileOnServer.html#ad18e589e07bd0f362efdd46d2eeda871", null ],
    [ "deleteFile", "classArServerDeleteFileOnServer.html#ab9dda5d50f400be73dcae3caae7d516f", null ],
    [ "getDeletingFileName", "classArServerDeleteFileOnServer.html#ad1850b7e490b3bda9b798ed488e56eeb", null ],
    [ "remPostDeleteCallback", "classArServerDeleteFileOnServer.html#a23bd9007c4ac835123f27cf1ac09541b", null ],
    [ "remPreDeleteCallback", "classArServerDeleteFileOnServer.html#a9052d78b40306370aa80b9d71958c6ee", null ],
    [ "myBaseDir", "classArServerDeleteFileOnServer.html#a28c0d7b7f443312a7aa34050047f64e0", null ],
    [ "myDeleteFileCB", "classArServerDeleteFileOnServer.html#abbf6a9343a7ba7db0f4e35e9488d6185", null ],
    [ "myDeletingFileName", "classArServerDeleteFileOnServer.html#a49c671deebc02811ee452b0d92c12d5b", null ],
    [ "myPostDeleteCallbacks", "classArServerDeleteFileOnServer.html#ad9550b6815c3e3ea54a5ba44f3816446", null ],
    [ "myPreDeleteCallbacks", "classArServerDeleteFileOnServer.html#a270893b6ded99ac2d418b42ac7cca393", null ],
    [ "myServer", "classArServerDeleteFileOnServer.html#a60f0b3599275580b0d691bce562a97ca", null ]
];