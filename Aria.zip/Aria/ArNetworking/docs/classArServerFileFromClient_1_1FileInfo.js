var classArServerFileFromClient_1_1FileInfo =
[
    [ "FileInfo", "classArServerFileFromClient_1_1FileInfo.html#ab672d9d984b6ca335f6daa24eb3c5da7", null ],
    [ "~FileInfo", "classArServerFileFromClient_1_1FileInfo.html#ac438717d9c7fbddd0cccef3dc3836031", null ],
    [ "myClient", "classArServerFileFromClient_1_1FileInfo.html#a1936b5bdd4fb22e80ff981d2679473e7", null ],
    [ "myClientCreationTime", "classArServerFileFromClient_1_1FileInfo.html#ae6f082bf104e8dee1f06801934819bb1", null ],
    [ "myFile", "classArServerFileFromClient_1_1FileInfo.html#a3cdd6669254a1e77d4e2871b8e24ae2a", null ],
    [ "myFileTimestamp", "classArServerFileFromClient_1_1FileInfo.html#ab3bf44d80537a959194801e01cf8d54d", null ],
    [ "myLastActivity", "classArServerFileFromClient_1_1FileInfo.html#affbd0e74152faff0ab5346b9bc785708", null ],
    [ "myRealFileName", "classArServerFileFromClient_1_1FileInfo.html#acd687ac54128e26bb5bfd69d6809971b", null ],
    [ "myStartedTransfer", "classArServerFileFromClient_1_1FileInfo.html#af6c83590aabc5343ab684ac27b489871", null ],
    [ "myTempFileName", "classArServerFileFromClient_1_1FileInfo.html#affae5b7e5fe9303bd4c40868c52d0126", null ]
];