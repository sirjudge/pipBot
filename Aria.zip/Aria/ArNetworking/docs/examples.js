var examples =
[
    [ "configClientToServe.cpp", "configClientToServe_8cpp-example.html", null ],
    [ "drawingsExample.cpp", "drawingsExample_8cpp-example.html", null ],
    [ "drawingsExampleWithRobot.cpp", "drawingsExampleWithRobot_8cpp-example.html", null ],
    [ "getVideoExample.cpp", "getVideoExample_8cpp-example.html", null ],
    [ "popupExample.cpp", "popupExample_8cpp-example.html", null ],
    [ "ptzCameraClientExample.cpp", "ptzCameraClientExample_8cpp-example.html", null ],
    [ "robotUpdateExample.cpp", "robotUpdateExample_8cpp-example.html", null ],
    [ "serverDemo.cpp", "serverDemo_8cpp-example.html", null ],
    [ "simpleServerExample.cpp", "simpleServerExample_8cpp-example.html", null ]
];