var classArNetCameraRequest =
[
    [ "ArNetCameraRequest", "classArNetCameraRequest.html#af0188ae835b902a585d990b63608bb87", null ],
    [ "requestPanTiltAbs", "classArNetCameraRequest.html#a0ce74f31bac004f0414a66a36a4e776b", null ],
    [ "requestPanTiltZoomAbs", "classArNetCameraRequest.html#a440ce2d91e43102dab8a340be99e87ab", null ],
    [ "setCameraName", "classArNetCameraRequest.html#aa030aeb5201cddf4819b3fe31a98efd7", null ]
];