var structItem =
[
    [ "name", "structItem.html#a342b7a351c9ae1c5430aa3ef65b670bd", null ],
    [ "value", "structItem.html#a49aec685c872d1b9a221c8592ab52a8c", null ]
];