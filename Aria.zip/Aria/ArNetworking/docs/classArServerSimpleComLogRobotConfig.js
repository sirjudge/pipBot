var classArServerSimpleComLogRobotConfig =
[
    [ "ArServerSimpleComLogRobotConfig", "classArServerSimpleComLogRobotConfig.html#a431dd55e91646fd6f2712356aca73002", null ],
    [ "logConfig", "classArServerSimpleComLogRobotConfig.html#a8972ae6b6d33b644cedb343715d0720f", null ],
    [ "logMovementConfig", "classArServerSimpleComLogRobotConfig.html#a9a996fe0f677e90a9725c3d002b2d6b1", null ],
    [ "logOrigConfig", "classArServerSimpleComLogRobotConfig.html#a1fcddaf69b773f8f1316fd5af8851b82", null ],
    [ "popupConfig", "classArServerSimpleComLogRobotConfig.html#ab48df0732468afd39cf77811ef3d83df", null ],
    [ "popupMovementConfig", "classArServerSimpleComLogRobotConfig.html#a22da2351f332a066238e42f41f1a4912", null ],
    [ "popupOrigConfig", "classArServerSimpleComLogRobotConfig.html#adf851f8199de981ff1fcd3a462bc5e84", null ]
];