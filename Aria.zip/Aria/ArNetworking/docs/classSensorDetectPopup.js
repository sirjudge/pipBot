var classSensorDetectPopup =
[
    [ "SensorDetectPopup", "classSensorDetectPopup.html#a176cae5018b13cc1fb2e727f74f0e242", null ],
    [ "popupClosed", "classSensorDetectPopup.html#ab94ccbef97b46bbd2bc173e9db30d306", null ],
    [ "sensorTask", "classSensorDetectPopup.html#aa85f6c8e45eeb576922151c67d4bbbf6", null ],
    [ "myPopupClosedCB", "classSensorDetectPopup.html#af82c24053bb2115628bb16d2a7824ec4", null ],
    [ "myPopupDisplayed", "classSensorDetectPopup.html#a153752cd67025b7e8f07c05c378fa475", null ],
    [ "myPopupServer", "classSensorDetectPopup.html#ae9bb25dadda759e8c583ad197ea766ac", null ],
    [ "myPrevObstacleAngle", "classSensorDetectPopup.html#a07cd92a62a7baf41d19f609b93de27cd", null ],
    [ "myPrevObstacleAngleValid", "classSensorDetectPopup.html#af4f28ae8a03a9a940ee6078383b94f42", null ],
    [ "myRobot", "classSensorDetectPopup.html#a4f89ce29c0409c60a8ac10ba8fcceac8", null ]
];