var classArServerFileToClient =
[
    [ "ArServerFileToClient", "classArServerFileToClient.html#a8b60745ac5c00f736546398b1ad470ff", null ],
    [ "~ArServerFileToClient", "classArServerFileToClient.html#a02b514b8fd286eb6bd2a31fe5634bd88", null ],
    [ "doGetFile", "classArServerFileToClient.html#a3506fdbca49808e423463be37fc2e6c9", null ],
    [ "getFile", "classArServerFileToClient.html#aa46dda943a13cb4dde0c26f1f3b35289", null ],
    [ "getFileWithTimestamp", "classArServerFileToClient.html#a59e080d40f33d9dc09900ba52701a70b", null ],
    [ "myBaseDir", "classArServerFileToClient.html#a6c8ad5df76fa9921ffaaa4385caabfa6", null ],
    [ "myGetFileCB", "classArServerFileToClient.html#a13b9c96e31cb44d4b82d5e4a5f618262", null ],
    [ "myGetFileWithTimestampCB", "classArServerFileToClient.html#a827483a7d28155d0792d59b7351ca12e", null ],
    [ "myServer", "classArServerFileToClient.html#a39604496813ef0be6f3e99fe74cd50d8", null ]
];