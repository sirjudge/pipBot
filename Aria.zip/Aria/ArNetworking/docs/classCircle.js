var classCircle =
[
    [ "Circle", "classCircle.html#a02dd4e6afe1df5a16b1f3ee2ae5b8051", null ],
    [ "~Circle", "classCircle.html#ae3f30436e645d73e368e8ee55f8d1650", null ],
    [ "setNumPoints", "classCircle.html#a36fd9cf27d46824f293088fd0545fa91", null ],
    [ "setPos", "classCircle.html#a82bb144f4d47fec91a79a946bcbb4831", null ],
    [ "setRadius", "classCircle.html#a6c5164e476c4dc5133e8a1615a0a8d75", null ]
];